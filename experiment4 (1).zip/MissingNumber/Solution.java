
// 268. Missing Number
import java.util.Arrays;

class Solution {
    public int missingNumber(int[] nums) {
        Arrays.sort(nums);
        int j = 0;
        for (int num : nums) {
            if (j == num) {
                j++;
            }
        }
        return j;
    }
}
